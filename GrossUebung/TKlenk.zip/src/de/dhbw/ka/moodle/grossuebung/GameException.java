package de.dhbw.ka.moodle.grossuebung;

public class GameException extends Exception {
    public GameException(String msg) {
        super(msg);
    }
}
